package config;

public enum PipelineType {
	inOrder,outOfOrder,statistical
}
