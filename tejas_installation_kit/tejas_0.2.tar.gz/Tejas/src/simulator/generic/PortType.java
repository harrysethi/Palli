package generic;

public enum PortType 
{
	FirstComeFirstServe,
	PriorityBased,
	Unlimited
}