package memorysystem;

public enum MESI {
	MODIFIED,
	EXCLUSIVE,
	SHARED,
	INVALID,
}
